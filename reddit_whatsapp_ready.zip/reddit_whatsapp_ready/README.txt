REDDIT -> WHATSAPP GROUP MONITOR

Ready Python source. No credentials included.

IMPORTANT
- Requires an approved Reddit API application and credentials.
- Requires a working Green API instance linked to WhatsApp and the group ID.
- Green API is unofficial; WhatsApp may restrict accounts.
- Free hosting and third-party free quotas are not guaranteed.
- Polling the 100 most recent submissions and comments may miss entries during heavy activity, API outages, or rate limits.
- This captures only public Reddit content, not private messages.

FROM IPHONE
1. Open replit.com in Safari, create a Python project, and upload main.py and requirements.txt.
2. Install requirements with pip install -r requirements.txt (if the hosting interface doesn't install them automatically).
3. Add each variable from .env.example in the host's Secrets/Environment settings. Do NOT paste tokens into public source code.
4. Obtain Reddit app credentials through Reddit's approved developer access process.
5. Set up Green API and connect the WhatsApp account and target group; get GREEN_ID, GREEN_TOKEN, and WHATSAPP_GROUP_ID.
6. Run python main.py and inspect logs.
7. For continuous execution, use a host with a persistent process. Free Replit projects may sleep.

The first run records recent entries without sending them, unless SEND_EXISTING=true. Database seen.sqlite3 prevents duplicates while retained. Do not publish the database if you consider the monitoring log confidential.
