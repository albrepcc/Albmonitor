import os, time, sqlite3, logging
from datetime import datetime, timezone
import requests
import praw

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
REQUIRED = ['REDDIT_CLIENT_ID','REDDIT_CLIENT_SECRET','GREEN_ID','GREEN_TOKEN','WHATSAPP_GROUP_ID']
missing = [key for key in REQUIRED if not os.getenv(key)]
if missing:
    raise SystemExit('Missing environment variables: ' + ', '.join(missing))

reddit = praw.Reddit(client_id=os.environ['REDDIT_CLIENT_ID'],client_secret=os.environ['REDDIT_CLIENT_SECRET'],user_agent='AlbaniaPublicPostsMonitor/1.0 (contact: operator)')
subreddit = reddit.subreddit(os.getenv('SUBREDDIT','albania'))
conn = sqlite3.connect('seen.sqlite3')
conn.execute('CREATE TABLE IF NOT EXISTS seen (id TEXT PRIMARY KEY)')
conn.commit()
interval = max(60, int(os.getenv('CHECK_SECONDS','120')))

def send(text):
    url = f"https://api.green-api.com/waInstance{os.environ['GREEN_ID']}/sendMessage/{os.environ['GREEN_TOKEN']}"
    response = requests.post(url,json={'chatId':os.environ['WHATSAPP_GROUP_ID'],'message':text[:18000]},timeout=30)
    response.raise_for_status()

def format_item(item):
    is_post = isinstance(item, praw.models.Submission)
    content = f"{item.title}\n\n{item.selftext}" if is_post else item.body
    stamp = datetime.fromtimestamp(item.created_utc,timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    return (f"Reddit {'POST' if is_post else 'COMMENT'} | r/{subreddit.display_name}\n"
            f"Author: u/{item.author or '[deleted]'}\nID: {item.fullname}\nTime: {stamp}\n\n"
            f"{content[:14000]}\n\nhttps://www.reddit.com{item.permalink}")

def poll(first_run=False):
    items = list(subreddit.new(limit=100)) + list(subreddit.comments(limit=100))
    for item in sorted(items,key=lambda x:x.created_utc):
        if conn.execute('SELECT 1 FROM seen WHERE id=?',(item.fullname,)).fetchone():
            continue
        if first_run and os.getenv('SEND_EXISTING','false').lower() != 'true':
            conn.execute('INSERT INTO seen VALUES (?)',(item.fullname,))
            conn.commit()
            continue
        send(format_item(item))
        conn.execute('INSERT INTO seen VALUES (?)',(item.fullname,))
        conn.commit()
        logging.info('Sent %s',item.fullname)

first=True
while True:
    try:
        poll(first)
        first=False
    except Exception:
        logging.exception('Polling failed; retrying')
    time.sleep(interval)
